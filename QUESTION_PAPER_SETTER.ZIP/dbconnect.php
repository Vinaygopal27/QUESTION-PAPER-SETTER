<?php
$connect=mysqli_connect("localhost","root","");
mysqli_select_db($connect,"php_question_paper_generator");
?>
